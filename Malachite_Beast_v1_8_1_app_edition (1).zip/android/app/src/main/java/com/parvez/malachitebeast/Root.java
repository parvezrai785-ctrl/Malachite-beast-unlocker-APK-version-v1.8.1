package com.parvez.malachitebeast;

import android.os.Handler;
import android.os.Looper;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Runs shell commands as root (via su) off the UI thread. */
final class Root {
    interface Callback { void done(String out, int code); }

    static final String MOD = "/data/adb/modules/malachite_beast_unlocker";
    static final String STATE = "/data/adb/malachite_beast_unlocker";
    static final String BC = "sh " + MOD + "/bin/beastctl";

    private static final ExecutorService EX = Executors.newSingleThreadExecutor();
    private static final Handler UI = new Handler(Looper.getMainLooper());

    private Root() {}

    static void run(final String cmd, final Callback cb) {
        EX.execute(new Runnable() {
            @Override public void run() {
                String out;
                int code;
                try {
                    Process p = new ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start();
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] buf = new byte[4096];
                    int n;
                    InputStream in = p.getInputStream();
                    while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                    in.close();
                    code = p.waitFor();
                    out = bo.toString("UTF-8");
                } catch (Exception e) {
                    out = "su failed: " + e.getMessage();
                    code = -1;
                }
                final String o = out;
                final int c = code;
                if (cb != null) UI.post(new Runnable() {
                    @Override public void run() { cb.done(o, c); }
                });
            }
        });
    }
}
