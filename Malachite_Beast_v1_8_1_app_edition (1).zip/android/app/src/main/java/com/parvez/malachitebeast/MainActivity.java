package com.parvez.malachitebeast;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.widget.ImageView;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {

    // id, label, subtitle, color, icon
    private static final String[][] MODES = {
            {"battery", "Battery", "60 Hz \u2022 cooler daily use", "#20E59A", "\uD83D\uDD0B"},
            {"balanced", "Balanced", "Default Hz \u2022 everyday", "#FFD84A", "\u2696\uFE0F"},
            {"gaming", "Gaming", "Default Hz \u2022 performance", "#45A7FF", "\uD83C\uDFAE"},
            {"esport90", "Esport 90", "90 Hz \u2022 performance", "#C16CFF", "\u26A1"},
            {"esport120", "Esport 120", "120 Hz \u2022 maximum", "#FF5363", "\uD83D\uDD25"},
    };
    private static final String[] GPU_MODES = {"powersave", "balance", "performance", "fast"};

    private static final int BG = Color.parseColor("#05060A");
    private static final int PANEL = Color.parseColor("#14172A");
    private static final int MUTED = Color.parseColor("#9AA3B8");

    private final Map<String, LinearLayout> cards = new HashMap<String, LinearLayout>();
    private LinearLayout homeSec, appsSec, aboutSec, appsList;
    private TextView statusView, chipsView, autoSub, aboutInfo;
    private Switch autoSwitch;
    private final Button[] tabBtns = new Button[3];
    private boolean syncing = false;
    private String currentMode = "balanced";

    // ---------------------------------------------------------------- helpers
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private GradientDrawable rounded(int fill, int stroke, int strokeDp, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), stroke);
        return d;
    }

    private TextView tv(String text, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button btn(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(rounded(Color.parseColor("#262B44"), 0, 0, 14));
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout.LayoutParams lp(int w, int h, float weight, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private static String val(String out, String key) {
        for (String line : out.split("\n")) {
            if (line.startsWith(key + "=")) return line.substring(key.length() + 1).trim();
        }
        return "";
    }

    private static String[] meta(String id) {
        for (String[] m : MODES) if (m[0].equals(id)) return m;
        return MODES[1];
    }

    // --------------------------------------------------------------------- UI
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(28));
        scroll.addView(root, new ViewGroup.LayoutParams(-1, -2));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(dp(56), dp(56));
        llp.setMargins(0, 0, dp(12), 0);
        head.addView(logo, llp);
        LinearLayout ht = new LinearLayout(this);
        ht.setOrientation(LinearLayout.VERTICAL);
        ht.addView(tv("MBP APK", 24, Color.WHITE, true));
        ht.addView(tv("v1.8.1 \u2022 DR.Parvez Dev", 12, MUTED, false));
        head.addView(ht);
        root.addView(head);
        chipsView = tv("Reading device\u2026", 12, Color.parseColor("#CBD2E2"), false);
        chipsView.setPadding(0, dp(8), 0, dp(12));
        root.addView(chipsView);

        // tabs
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabBtns[0] = btn("Profiles", new View.OnClickListener() {
            @Override public void onClick(View v) { showTab(0); }
        });
        tabs.addView(tabBtns[0], lp(0, -2, 1, 0, 0, 4, 0));
        tabBtns[1] = btn("Apps", new View.OnClickListener() {
            @Override public void onClick(View v) { showTab(1); }
        });
        tabs.addView(tabBtns[1], lp(0, -2, 1, 4, 0, 4, 0));
        tabBtns[2] = btn("About", new View.OnClickListener() {
            @Override public void onClick(View v) { showTab(2); }
        });
        tabs.addView(tabBtns[2], lp(0, -2, 1, 4, 0, 0, 0));
        root.addView(tabs);

        homeSec = section();
        appsSec = section();
        aboutSec = section();
        root.addView(homeSec);
        root.addView(appsSec);
        root.addView(aboutSec);

        buildHome();
        buildApps();
        buildAbout();
        showTab(0);

        setContentView(scroll);
    }

    private LinearLayout section() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(0, dp(14), 0, 0);
        return l;
    }

    private void showTab(int i) {
        homeSec.setVisibility(i == 0 ? View.VISIBLE : View.GONE);
        appsSec.setVisibility(i == 1 ? View.VISIBLE : View.GONE);
        aboutSec.setVisibility(i == 2 ? View.VISIBLE : View.GONE);
        for (int k = 0; k < 3; k++) {
            tabBtns[k].setBackground(rounded(k == i ? Color.parseColor("#2F6B4F") : Color.parseColor("#262B44"), 0, 0, 14));
        }
        if (i == 1) loadApps();
    }

    private void buildHome() {
        homeSec.addView(tv("Performance Profiles", 19, Color.WHITE, true));
        TextView sub = tv("Balanced is the default. It keeps your phone's refresh-rate setting.", 12, MUTED, false);
        sub.setPadding(0, 0, 0, dp(10));
        homeSec.addView(sub);

        LinearLayout row = null;
        for (int i = 0; i < MODES.length; i++) {
            if (i % 2 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                homeSec.addView(row, lp(-1, -2, 0, 0, 0, 0, 8));
            }
            final String[] m = MODES[i];
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(14), dp(14), dp(14));
            card.setMinimumHeight(dp(92));
            card.addView(tv(m[1], 16, Color.parseColor(m[3]), true));
            TextView s = tv(m[2], 11, MUTED, false);
            s.setPadding(0, dp(6), 0, 0);
            card.addView(s);
            card.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { applyMode(m[0]); }
            });
            cards.put(m[0], card);
            row.addView(card, lp(0, -2, 1, i % 2 == 0 ? 0 : 4, 0, i % 2 == 0 ? 4 : 0, 0));
        }
        if (MODES.length % 2 == 1) {
            row.addView(new View(this), lp(0, 1, 1, 4, 0, 0, 0));
        }

        Button restore = btn("Restore Stock", new View.OnClickListener() {
            @Override public void onClick(View v) {
                Root.run(Root.BC + " restore 2>&1", new Root.Callback() {
                    @Override public void done(String out, int code) {
                        toast("STOCK SETTINGS RESTORED");
                        refresh();
                    }
                });
            }
        });
        restore.setBackground(rounded(Color.parseColor("#3A1620"), Color.parseColor("#66FF4B64"), 1, 14));
        homeSec.addView(restore, lp(-1, -2, 0, 0, 4, 0, 0));

        // GPU governor card
        LinearLayout gpu = new LinearLayout(this);
        gpu.setOrientation(LinearLayout.VERTICAL);
        gpu.setPadding(dp(14), dp(14), dp(14), dp(14));
        gpu.setBackground(rounded(PANEL, 0, 0, 18));
        gpu.addView(tv("GPU Governor mode", 15, Color.WHITE, true));
        TextView gs = tv("Applies right away. Picking a profile above sets this again.", 11, MUTED, false);
        gs.setPadding(0, dp(2), 0, dp(8));
        gpu.addView(gs);
        LinearLayout gr = new LinearLayout(this);
        gr.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < GPU_MODES.length; i++) {
            final String g = GPU_MODES[i];
            Button gb = btn(g.equals("powersave") ? "Save" : g.equals("balance") ? "Bal" : g.equals("performance") ? "Perf" : "Fast",
                    new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            Root.run(Root.BC + " gpu-mode " + g + " 2>&1; echo rc=$?", new Root.Callback() {
                                @Override public void done(String out, int code) {
                                    toast(out.trim().endsWith("rc=0") ? "GPU: " + g.toUpperCase() : "GPU mode change failed");
                                    refresh();
                                }
                            });
                        }
                    });
            gr.addView(gb, lp(0, -2, 1, i == 0 ? 0 : 3, 0, i == GPU_MODES.length - 1 ? 0 : 3, 0));
        }
        gpu.addView(gr);
        homeSec.addView(gpu, lp(-1, -2, 0, 0, 12, 0, 0));

        statusView = tv("Loading\u2026", 10, Color.parseColor("#BFC7D8"), false);
        statusView.setTypeface(Typeface.MONOSPACE);
        statusView.setPadding(dp(12), dp(12), dp(12), dp(12));
        statusView.setBackground(rounded(Color.parseColor("#80000000"), 0, 0, 14));
        homeSec.addView(statusView, lp(-1, -2, 0, 0, 12, 0, 0));
    }

    private void buildApps() {
        appsSec.addView(tv("Per-App Profiles", 19, Color.WHITE, true));
        TextView sub = tv("Assign a profile to an app. Turn on auto switching to apply it when the app is in front.", 12, MUTED, false);
        sub.setPadding(0, 0, 0, dp(10));
        appsSec.addView(sub);

        LinearLayout tog = new LinearLayout(this);
        tog.setOrientation(LinearLayout.HORIZONTAL);
        tog.setGravity(Gravity.CENTER_VERTICAL);
        tog.setPadding(dp(14), dp(10), dp(14), dp(10));
        tog.setBackground(rounded(PANEL, 0, 0, 18));
        LinearLayout tl = new LinearLayout(this);
        tl.setOrientation(LinearLayout.VERTICAL);
        tl.addView(tv("Auto Switching", 15, Color.WHITE, true));
        autoSub = tv("Off \u2022 using Balanced by default", 11, MUTED, false);
        tl.addView(autoSub);
        tog.addView(tl, lp(0, -2, 1, 0, 0, 0, 0));
        autoSwitch = new Switch(this);
        autoSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton v, final boolean on) {
                if (syncing) return;
                String cmd = on ? "touch " + Root.STATE + "/auto_enable" : "rm -f " + Root.STATE + "/auto_enable";
                Root.run(cmd, new Root.Callback() {
                    @Override public void done(String out, int code) {
                        toast(on ? "AUTO SWITCHING ENABLED" : "AUTO SWITCHING DISABLED");
                        autoSub.setText(on ? "On \u2022 profiles follow the foreground app" : "Off \u2022 using Balanced by default");
                    }
                });
            }
        });
        tog.addView(autoSwitch);
        appsSec.addView(tog);

        Button add = btn("+ Add App", new View.OnClickListener() {
            @Override public void onClick(View v) { openAdd(); }
        });
        appsSec.addView(add, lp(-1, -2, 0, 0, 10, 0, 6));

        appsList = new LinearLayout(this);
        appsList.setOrientation(LinearLayout.VERTICAL);
        appsSec.addView(appsList);
    }

    private void link(LinearLayout parent, String title, final String url) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(12), dp(14), dp(12));
        box.setBackground(rounded(PANEL, 0, 0, 14));
        box.addView(tv(title, 15, Color.WHITE, true));
        TextView u = tv(url, 11, Color.parseColor("#6CB6FF"), false);
        u.setPadding(0, dp(4), 0, 0);
        box.addView(u);
        box.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception e) {
                    toast("No browser found");
                }
            }
        });
        parent.addView(box, lp(-1, -2, 0, 0, 0, 0, 8));
    }

    private void buildAbout() {
        aboutSec.addView(tv("Developer", 19, Color.WHITE, true));
        TextView dev = tv("DR.Parvez Dev", 14, Color.parseColor("#CBD2E2"), false);
        dev.setPadding(0, dp(4), 0, dp(10));
        aboutSec.addView(dev);
        link(aboutSec, "Instagram", "https://www.instagram.com/parvez_.9.1.1?vrfl=ZGRjbHl2YnA2OGpp");
        link(aboutSec, "GitHub", "https://github.com/parvezrai785-ctrl");

        TextView t = tv("Device", 19, Color.WHITE, true);
        t.setPadding(0, dp(10), 0, 0);
        aboutSec.addView(t);
        aboutInfo = tv("", 13, Color.parseColor("#CBD2E2"), false);
        aboutInfo.setPadding(0, dp(6), 0, dp(10));
        aboutSec.addView(aboutInfo);
        aboutSec.addView(tv("Thermal protection is not disabled. This app needs root: allow the request in your "
                + "Magisk / KernelSU / APatch manager.", 12, MUTED, false));
    }

    // ------------------------------------------------------------------ logic
    private void highlight(String mode) {
        currentMode = mode;
        for (Map.Entry<String, LinearLayout> e : cards.entrySet()) {
            boolean on = e.getKey().equals(mode);
            int c = Color.parseColor(meta(e.getKey())[3]);
            e.getValue().setBackground(on ? rounded(PANEL, c, 2, 18) : rounded(PANEL, 0, 0, 18));
        }
    }

    private void applyMode(final String mode) {
        Root.run(Root.BC + " apply " + mode + " 2>&1; echo rc=$?", new Root.Callback() {
            @Override public void done(String out, int code) {
                boolean ok = out.trim().endsWith("rc=0");
                toast(ok ? meta(mode)[1].toUpperCase() + " ENABLED" : "FAILED - check status / root access");
                refresh();
            }
        });
    }

    private void refresh() {
        String cmd = Root.BC + " status 2>&1; if [ -f " + Root.STATE + "/auto_enable ]; then echo auto=ON; else echo auto=OFF; fi";
        Root.run(cmd, new Root.Callback() {
            @Override public void done(String out, int code) {
                if (!out.contains("version=")) {
                    statusView.setText("No root access, or the module isn't active.\n\n"
                            + "1) Allow root for Malachite Beast in your root manager.\n"
                            + "2) Make sure the Malachite Beast module is enabled and you rebooted after flashing.\n\n"
                            + out.trim());
                    return;
                }
                statusView.setText(out.trim());
                String mode = val(out, "mode");
                highlight(mode.length() == 0 || mode.equals("stock") ? "balanced" : mode);
                String dev = val(out, "device"), and = val(out, "android"), ker = val(out, "kernel");
                chipsView.setText(dev + "  \u2022  Android " + and + "  \u2022  " + ker);
                aboutInfo.setText("Version   1.8.1\nDevice    " + dev
                        + "\nAndroid   " + and + "\nKernel    " + ker);
                boolean on = val(out, "auto").equals("ON");
                syncing = true;
                autoSwitch.setChecked(on);
                syncing = false;
                autoSub.setText(on ? "On \u2022 profiles follow the foreground app" : "Off \u2022 using Balanced by default");
            }
        });
    }

    private String labelOf(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
        } catch (Exception e) {
            return pkg;
        }
    }

    private void loadApps() {
        Root.run(Root.BC + " list-apps", new Root.Callback() {
            @Override public void done(String out, int code) {
                appsList.removeAllViews();
                String t = out.trim();
                if (t.length() == 0 || code != 0) {
                    appsList.addView(tv("No app profiles yet.", 12, MUTED, false));
                    return;
                }
                for (String line : t.split("\n")) {
                    int i = line.indexOf('=');
                    if (i <= 0) continue;
                    final String pkg = line.substring(0, i).trim();
                    final String mode = line.substring(i + 1).trim();
                    appsList.addView(appRow(pkg, mode));
                }
            }
        });
    }

    private View appRow(final String pkg, final String mode) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(12), dp(8), dp(8), dp(8));
        r.setBackground(rounded(PANEL, 0, 0, 14));

        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        TextView n = tv(labelOf(pkg), 14, Color.WHITE, true);
        n.setSingleLine(true);
        names.addView(n);
        TextView p = tv(pkg, 10, MUTED, false);
        p.setSingleLine(true);
        names.addView(p);
        r.addView(names, lp(0, -2, 1, 0, 0, 6, 0));

        Button mb = btn(meta(mode)[1], new View.OnClickListener() {
            @Override public void onClick(View v) { pickProfile(pkg); }
        });
        mb.setTextColor(Color.parseColor(meta(mode)[3]));
        r.addView(mb, lp(-2, -2, 0, 0, 0, 4, 0));

        Button rm = btn("\u2715", new View.OnClickListener() {
            @Override public void onClick(View v) {
                Root.run(Root.BC + " remove-app " + pkg, new Root.Callback() {
                    @Override public void done(String out, int code) {
                        toast("PROFILE REMOVED");
                        loadApps();
                    }
                });
            }
        });
        r.addView(rm, lp(-2, -2, 0, 0, 0, 0, 0));

        LinearLayout.LayoutParams wrap = lp(-1, -2, 0, 0, 0, 0, 6);
        r.setLayoutParams(wrap);
        return r;
    }

    private void pickProfile(final String pkg) {
        final String[] labels = new String[MODES.length];
        for (int i = 0; i < MODES.length; i++) labels[i] = MODES[i][1];
        new AlertDialog.Builder(this)
                .setTitle("Profile for " + labelOf(pkg))
                .setItems(labels, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        Root.run(Root.BC + " add-app " + pkg + " " + MODES[which][0], new Root.Callback() {
                            @Override public void done(String out, int code) {
                                toast("APP PROFILE SAVED");
                                loadApps();
                            }
                        });
                    }
                }).show();
    }

    private void openAdd() {
        new Thread(new Runnable() {
            @Override public void run() {
                final List<String[]> apps = installedApps();
                runOnUiThread(new Runnable() {
                    @Override public void run() { showPicker(apps); }
                });
            }
        }).start();
    }

    private List<String[]> installedApps() {
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> ris = pm.queryIntentActivities(main, 0);
        Set<String> seen = new HashSet<String>();
        List<String[]> out = new ArrayList<String[]>();
        for (ResolveInfo ri : ris) {
            String pkg = ri.activityInfo.packageName;
            if (!seen.add(pkg)) continue;
            out.add(new String[]{ri.loadLabel(pm).toString(), pkg});
        }
        Collections.sort(out, new Comparator<String[]>() {
            @Override public int compare(String[] a, String[] b) { return a[0].compareToIgnoreCase(b[0]); }
        });
        return out;
    }

    private void showPicker(final List<String[]> all) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), 0);
        final EditText search = new EditText(this);
        search.setHint("Search apps\u2026");
        search.setSingleLine(true);
        box.addView(search);
        final ListView lv = new ListView(this);
        box.addView(lv, new LinearLayout.LayoutParams(-1, dp(360)));

        final List<String[]> shown = new ArrayList<String[]>(all);
        final ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, new ArrayList<String>());
        final Runnable fill = new Runnable() {
            @Override public void run() {
                ad.clear();
                for (String[] a : shown) ad.add(a[0] + "\n" + a[1]);
                ad.notifyDataSetChanged();
            }
        };
        fill.run();
        lv.setAdapter(ad);

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable e) {
                String q = e.toString().toLowerCase();
                shown.clear();
                for (String[] a : all) {
                    if (a[0].toLowerCase().contains(q) || a[1].toLowerCase().contains(q)) shown.add(a);
                }
                fill.run();
            }
        });

        final AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Add App").setView(box)
                .setNegativeButton("Cancel", null).create();
        lv.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override public void onItemClick(android.widget.AdapterView<?> p, View v, int pos, long id) {
                String pkg = shown.get(pos)[1];
                dlg.dismiss();
                pickProfile(pkg);
            }
        });
        dlg.show();
    }

    @Override protected void onResume() {
        super.onResume();
        refresh();
    }
}
