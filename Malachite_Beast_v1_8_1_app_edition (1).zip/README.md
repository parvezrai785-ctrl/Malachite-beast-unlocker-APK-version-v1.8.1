# Malachite Beast v1.8.1 - native app edition

The WebUI is gone. The module now ships a small native Android app (`com.parvez.malachitebeast`)
that installs itself when you flash the module.

## Get the flashable zip (no PC tools needed)
1. Create a free GitHub repo and upload everything in this folder (keep the folder layout).
2. Open the **Actions** tab -> **Build flashable module** -> **Run workflow**.
3. When it finishes (about 3-5 min), download the artifact `Malachite_Beast_v1.8.1_flashable`.
4. Unzip once to get `Malachite_Beast_GPU_Governor_v1_8_1.zip` and flash that in Magisk / KernelSU / APatch.
5. Reboot, open **Malachite Beast** from the app drawer, allow the root request.

## Folders
- `android/` - app source (plain Java, no libraries, so it stays light)
- `module/`  - the flashable module (WebUI removed, `customize.sh` installs `app/MalachiteBeast.apk`)
- `.github/workflows/build.yml` - builds the APK, drops it into `module/app/`, zips the module

## Build by hand instead
Open `android/` in Android Studio, build a signed release APK, copy it to
`module/app/MalachiteBeast.apk`, then zip the *contents* of `module/`.
