#!/system/bin/sh
MODDIR=${0%/*}
echo "Malachite Beast Unlocker + GPU Governor v1.8.1"
echo "Developer: DR.Parvez Dev  |  GPU Governor: Seyud, Tools-cx-app"
echo "Default: Balanced (phone refresh rate preserved)"
echo
sh "$MODDIR/bin/beastctl" status
echo
echo "Governor log level menu: sh $MODDIR/script/gov_menu.sh"
