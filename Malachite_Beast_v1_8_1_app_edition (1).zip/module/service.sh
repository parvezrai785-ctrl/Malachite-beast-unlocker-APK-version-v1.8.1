#!/system/bin/sh
MODDIR=${0%/*}
STATE=/data/adb/malachite_beast_unlocker
BC="sh $MODDIR/bin/beastctl"
mkdir -p "$STATE/apps"

# --- bundled GPU Governor (waits for login on its own; run in background) ---
mount -t debugfs none /sys/kernel/debug 2>/dev/null
( sh "$MODDIR/script/initsvc.sh" >/dev/null 2>&1 & )

# --- Malachite Beast ---
# Wait for the system to finish booting before touching display/CPU settings.
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 3; done
sleep 10

# --- make sure the app is installed (flash-time install can fail on some setups) ---
APP_PKG=com.parvez.malachitebeast
APK="$MODDIR/app/MalachiteBeast.apk"
if [ -f "$APK" ] && ! pm path "$APP_PKG" >/dev/null 2>&1; then
    cp -f "$APK" /data/local/tmp/mb_install.apk 2>/dev/null
    chmod 644 /data/local/tmp/mb_install.apk 2>/dev/null
    pm install -r /data/local/tmp/mb_install.apk >/dev/null 2>&1
    rm -f /data/local/tmp/mb_install.apk
fi

# Balanced is the default profile: restore saved defaults, then apply it.
$BC restore >/dev/null 2>&1
$BC apply balanced >/dev/null 2>&1
LAST="balanced"

while sleep 2; do
    [ -f "$STATE/auto_enable" ] || continue

    top="$(dumpsys activity activities 2>/dev/null |
        grep -m1 -E 'topResumedActivity|mResumedActivity' |
        sed -n 's/.* \([A-Za-z0-9._-]*\)\/[^ ]*.*/\1/p')"

    [ -n "$top" ] || continue

    mode="$(cat "$STATE/apps/$top" 2>/dev/null)"
    [ -n "$mode" ] || mode=balanced

    [ "$mode" = "$LAST" ] && continue

    $BC apply "$mode" >/dev/null 2>&1
    LAST="$mode"
done
