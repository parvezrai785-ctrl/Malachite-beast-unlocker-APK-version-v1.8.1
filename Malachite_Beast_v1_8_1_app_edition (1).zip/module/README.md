# Malachite Beast Unlocker + GPU Governor v1.8.0

Developer: DR.Parvez Dev  |  GPU Governor: Seyud, Tools-cx-app (GPL-3.0, bundled)
Target: Redmi Note 14 Pro 5G / Malachite (Dimensity 7300 class)

One zip = Malachite profiles (CPU + display) + the Mediatek Mali GPU Governor.
Do NOT also install the standalone GPU Governor module - the installer refuses if it finds it.

## Profiles -> what they set
| Profile    | Display        | CPU                     | GPU governor mode |
|------------|----------------|-------------------------|-------------------|
| Battery    | 60 Hz          | schedutil, 1.4/1.8 GHz  | powersave         |
| Balanced   | phone default  | schedutil, 1.8/2.2 GHz  | balance           |
| Gaming     | phone default  | performance, 2.0/2.5    | performance       |
| Esport 90  | 90 Hz          | performance, 2.0/2.5    | performance       |
| Esport 120 | 120 Hz         | performance, 2.0/2.5    | fast              |

GPU modes can be changed in `beast/profiles.conf` (`gpu_*` lines).

## GPU tuning (new)
- The governor only controls the GPU *while its mode says so*: in a game listed in
  `games.toml` it uses that game's mode, everywhere else the global mode.
  Malachite keeps both in sync: choosing a profile sets the global mode, and
  assigning a profile to an app (Per-App tab) also sets that app's mode in `games.toml`.
- On first install the governor config is replaced by a tuned one
  (`beast/gov_tuned.toml`: lower margins, faster ramp-up, short hold on ramp-down =
  cooler and steadier frame times). Your old file is kept as `config.toml.bak_malachite`.
  Game list entries are set to `performance`; BGMI (`com.pubg.imobile`) and CODM were added;
  old list kept as `games.toml.bak_malachite`.
- The governor also disables the kernel's GPU DVFS at boot (its own behaviour) so it has
  full control of GPU frequency.
- GPU mode can also be set from the app (GPU Governor card). Frequency table / voltages: edit `/data/adb/gpu_governor/config/` files.

## Safety
- Thermal protection is NOT disabled. No thermal or touch nodes are written.
- Wrong GPU voltages can freeze the phone - see the governor docs in `docs/`.
- Restore Stock / uninstall puts back the original governor mode and phone display/CPU settings.

## v1.8.0
- WebUI removed (it was laggy). Replaced by a native Android app: **Malachite Beast**.
- The app is bundled in the zip (`app/MalachiteBeast.apk`) and installs automatically when you flash
  (with a second try at boot if the flash-time install is blocked). Uninstalling the module removes the app.
- The app needs root: allow the root request the first time you open it.
- Added `beastctl gpu-mode <powersave|balance|performance|fast>`.
