#!/system/bin/sh
# Put the phone back to stock, then remove module state (incl. GPU governor data).
MODDIR=${0%/*}
sh "$MODDIR/bin/beastctl" restore >/dev/null 2>&1
killall gpugovernor 2>/dev/null
pm uninstall com.parvez.malachitebeast >/dev/null 2>&1
rm -rf /data/adb/malachite_beast_unlocker
rm -rf /data/adb/gpu_governor
