ui_print " "
ui_print "========================================"
ui_print "          MBP  v1.8.1"
ui_print "          DR.Parvez Dev"
ui_print "========================================"
ui_print " "
ui_print "Target: Redmi Note 14 Pro 5G / Malachite"
ui_print "Android: $(getprop ro.build.version.release)"
ui_print "Kernel: $(uname -r)"
ui_print " "
ui_print "WHAT THIS MODULE DOES"
ui_print "- Battery / Balanced / Gaming / Esport 90 / 120"
ui_print "- CPU + display profiles"
ui_print "- Per-app profiles"
ui_print "- Simple native app (MBP APK)"
ui_print " "
ui_print "SAFETY"
ui_print "- Thermal protection is NOT disabled."
ui_print "- No touch/thermal kernel writes."
ui_print " "
ui_print "Installing..."

# Two copies of the governor would fight each other.
for d in /data/adb/modules/Mediatek_Mali_GPU_Governor /data/adb/ksu/modules/Mediatek_Mali_GPU_Governor; do
  if [ -d "$d" ] && [ ! -f "$d/remove" ]; then
    ui_print "!! A conflicting standalone module was found."
    ui_print "!! This zip already includes it. Remove the other"
    ui_print "!! module, reboot, then flash this zip again."
    abort "Conflict: standalone module installed"
  fi
done

set_perm_recursive "$MODPATH" 0 0 0755 0644
chmod 755 "$MODPATH"/bin/* "$MODPATH"/*.sh "$MODPATH"/script/*.sh

# --- install the GPU governor (its own setup: config, freq table, game list) ---
sh "$MODPATH/script/setup.sh" >/dev/null 2>&1
[ "$?" != "0" ] && abort "Setup failed"
rm -f "$MODPATH/script/setup.sh"
rm -rf "$MODPATH/config"

STATE=/data/adb/malachite_beast_unlocker
GOV=/data/adb/gpu_governor
mkdir -p "$STATE/apps" 2>/dev/null

# --- one-time Malachite tuning of the governor (old files are backed up) ---
if [ ! -f "$STATE/gpu_tuned_v1" ] && [ -d "$GOV/config" ]; then
  [ -f "$GOV/config/config.toml" ] && cp -f "$GOV/config/config.toml" "$GOV/config/config.toml.bak_malachite"
  cp -f "$MODPATH/beast/gov_tuned.toml" "$GOV/config/config.toml"
  chmod 0666 "$GOV/config/config.toml"
  sh "$MODPATH/bin/beastctl" gpu-games-init >/dev/null 2>&1
  touch "$STATE/gpu_tuned_v1"
fi
ui_print " "
ui_print "DEFAULT: Balanced - preserves phone refresh setting"

# --- install the Malachite Beast app (replaces the old WebUI) ---
APK="$MODPATH/app/MalachiteBeast.apk"
APP_PKG=com.parvez.malachitebeast
if [ -f "$APK" ]; then
  ui_print " "
  ui_print "Installing MBP APK..."
  cp -f "$APK" /data/local/tmp/mb_install.apk 2>/dev/null
  chmod 644 /data/local/tmp/mb_install.apk 2>/dev/null
  if pm install -r /data/local/tmp/mb_install.apk >/dev/null 2>&1 \
     || { pm uninstall "$APP_PKG" >/dev/null 2>&1; pm install /data/local/tmp/mb_install.apk >/dev/null 2>&1; }; then
    ui_print "- App installed. Open 'MBP APK' from your app drawer."
  else
    ui_print "- Could not install right now; it will install after reboot."
  fi
  rm -f /data/local/tmp/mb_install.apk
else
  ui_print "- No app APK bundled in this zip (skipping app install)."
fi
ui_print " "
ui_print "Done. Reboot your phone."
